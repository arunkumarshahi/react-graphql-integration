import {addTODOActivity} from './updateActivity';

export default {
Mutation: {
    addTODOActivity
}
};