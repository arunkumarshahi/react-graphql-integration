export default {
    apolloTODODemo: {
    __typename:'apolloTodoDemo',
    todoActivity:[
    {
    __typename:'todoActivity',
    activityName:' ',
    status:' ',
    }
]
    }
}